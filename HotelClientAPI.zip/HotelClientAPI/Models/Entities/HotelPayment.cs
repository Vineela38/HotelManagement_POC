using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HotelClientAPI.Models.Entities
{
    public class HotelPayment
    {
         public string? BookingId{get;set;}
         [Required(ErrorMessage ="*")]
         //[Range(1,16,ErrorMessage ="Card Number Should not Exceed 16-Digits")]
        public long Creditcardnumber { get ; set; }


        [Required(ErrorMessage ="*")]
        public string Bankname{get;set;}


        [Required(ErrorMessage ="*")]
        public string Cardtype { get; set ; }


        [Required(ErrorMessage ="*")]
        //[StringLength(30,ErrorMessage ="Name on card should not exceed 30 characters")]
        //[RegularExpression(pattern:"^[A-Z]{30}",ErrorMessage ="Name on card must allow only alphabets ")]
        public string Nameoncard { get; set ; }


        [Required(ErrorMessage ="*")]
        public DateOnly Expirydate { get ; set ; }


        [Required(ErrorMessage ="*")]
        //[Range(1,3,ErrorMessage ="Cvv must takes only 3-Digits")]
        public int Cvv { get; set ; }


        [Required(ErrorMessage ="*")]
        //[RegularExpression(@"^\d{4}(\d{2})?$", ErrorMessage = "PIN must be a 4 or 6 digit number")]
        public int Pin { get ; set ; }

    //     [Required(ErrorMessage = "Bank Name is required.")]
    //     public string Bankname { get; set; }

    // [Required(ErrorMessage = "Credit/Debit Card Number is required.")]
    // [CreditCard(ErrorMessage = "Invalid credit card number.")]
    // public long Creditcardnumber { get; set; }

    // [Required(ErrorMessage = "Card Type is required.")]
    // public string Cardtype { get; set; }

    // [Required(ErrorMessage = "Card Holder Name is required.")]
    // [StringLength(100, ErrorMessage = "Card Holder Name cannot be longer than 100 characters.")]
    // public string Nameoncard { get; set; }

    // [Required(ErrorMessage = "Expiry Date is required.")]
    // [DataType(DataType.Date, ErrorMessage = "Invalid Expiry Date.")]
    // public DateTime Expirydate { get; set; }

    // [Required(ErrorMessage = "CVV is required.")]
    // [Range(100, 999, ErrorMessage = "CVV must be 3 digits.")]
    // public int Cvv { get; set; }

    // [Required(ErrorMessage = "Pin is required.")]
    // [StringLength(4, MinimumLength = 4, ErrorMessage = "Pin must be 4 digits.")]
    // [RegularExpression(@"^\d{4}$", ErrorMessage = "Pin must be numeric.")]
    // public int Pin { get; set; }

        
    }
}