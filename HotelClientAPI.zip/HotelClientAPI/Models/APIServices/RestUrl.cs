using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HotelClientAPI.Models.APIServices
{
    public class RestUrl
    {
        public const string ADMIN_URL="http://localhost:5284/api/hotelreservation/";
        public const string BOOKING_URL="http://localhost:5284/api/hotelbooking/";
        public const string Payment_url="http://localhost:5284/api/paymentdb/";
        public const string Signup_URL="http://localhost:5284/api/hotel/";
        
    }
}