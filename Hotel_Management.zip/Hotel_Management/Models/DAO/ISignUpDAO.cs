using Hotel_Management.Models.ENTITY;

namespace Hotel_Management.Models.DAO
{
    public interface ISignUpDAO
    {
        public string InsertCustomer(SignUp signUp );
        
        
    }
}